<template>
  <div>
       <!-- 小导航 -->
  <div class="select">
      <el-row>
        <el-col :span="24"><div class="grid-content bg-purple-dark">首页</div></el-col>
      </el-row>
  </div>    
    <div class="left" >
      <!-- <ul v-for="(item,idx) in searchData " :key="idx" class="als">
        
         <li> <span class="yul">{{item.title}}</span>
             <span>{{item.name}}</span>
             <span>{{item.address}}</span>
             <span>{{item.date}}</span> 
          </li>
          </ul> -->
        <el-table
         :data="tableData"
          @row-click="openDetails(tableData)"
          style="width: 100%">
          <el-table-column
            prop="title"
            label="标题"
             width="430"
            style=" text-align: center;">
          </el-table-column>
          <el-table-column
            prop="name"
            label="作者"
            width="140">
          </el-table-column>
          <el-table-column
            prop="address"
            label="分类"
            width="140">
          </el-table-column>
          <el-table-column
            prop="date"
            label="发布时间"
            width="160">
          </el-table-column>
        </el-table>
        
    
    </div>
<!-- 右侧 -->
   <div class="right">
 <!-- 第一侧栏 -->
      <div class="soone">
         <h4>全站搜索
           
         </h4>

         <div class="seek">
           <el-input v-model="input" placeholder="请输入内容"  id="inputk"></el-input>
           
           <el-button type="primary" @click="seek">搜索</el-button>
           
     
         </div>
      </div>   
 <!-- 第二侧栏 -->
         <div class="ranking">
           <h4>点击量排行</h4>
           <div class="table_s">
              <el-table
                :data="tableData"
                style="width: 90% "
                :default-sort = "{prop: 'date', order: 'descending'}"
                >
                <el-table-column
                  prop="title"
                  label="标题"
                    :formatter="formatter"
                  >
                </el-table-column>
                <el-table-column
                  prop="dianji"
                  label="点击"
                  width="80"
                  sortable
                  >
                </el-table-column>
              </el-table>

           </div>
         </div>
 <!-- 第三侧栏 -->
         <div class="ranking">
           <h4>最新讯息</h4>
           <div class="table_s">
              <el-table
                :data="tableData"
                style="width: 90% "
                :default-sort = "{prop: 'date', order: 'descending'}"
                >

                <el-table-column
                  prop="title"
                  label="标题"
                  :formatter="formatter"
                 
                  >
                </el-table-column>
                <el-table-column
                  prop="date"
                  label="发布时间"
                  width="120"
                  sortable
                  >
                </el-table-column>
              </el-table>

           </div>
         </div>         
    </div> 
    
</div>
</template>

<script>
export default {
   data() {
        return {
          counter:0,
          input:'',
           activeIndex: '1',
           activeIndex2: '1',
          tableData: [{
            title:'vue的独特见解',
            date: '2016-05-02',
            name: '王小虎',
            address: '北京',
            dianji:1
          }, {
            title:'angular的成长须知',
            date: '2016-05-04',
            name: '王小二',
            address: '金沙江路',
             dianji:7
          }, {
            title:'前段野史',
            date: '2016-05-04',
            name: '王小三',
            address: '金沙额江路',
             dianji:5
          }, {
            title:'node对于整个app',
            date: '2016-09-04',
            name: '王小四',
            address: '金沙是江路',
             dianji:17
          }, {
            title:'前段工程师必学',
            date: '2017-05-04',
            name: '王小小',
            address: '金沙他江路',
             dianji:27
          }, {
            title:'论逻辑的重要性',
            date: '2016-05-04',
            name: '王小虎',
            address: '金沙一江路',
             dianji:3
          }, {
            title:'的啰里啰嗦',
            date: '2016-05-04',
            name: '王小两',
            address: '金沙u江路',
             dianji:8
          }, {
            title:'javascript的起航',
            date: '2012-05-01',
            name: '王小说',
            address: '普陀区',
             dianji:10
          }, {
            title:'app的搭建',
            date: '2016-05-03',
            name: '王小大',
            address: '上海市普',
            dianji:3
          }]
        }
      
    },
      methods: {
        handleSelect(key, keyPath) {
          console.log(key, keyPath);
        },
        formatter(row, column) {
          return row.title
        },
        seek(){
         let arr = [];
         this.tableData.forEach((v)=>{
           if(v.name.indexOf(this.input) !== -1 || v.address.indexOf(this.input) !== -1 ||v.title.indexOf(this.input) !== -1){
             arr.push(v)
           }
         })
        this.tableData = arr
        }
        // cloo (row) {
        //   console.log(row)

        // }
        // openDetails(row, event, column) {
        //   console.log(row);
       
        //   console.log(event);
        //   console.log(column);
        // },
    },
    computed:{
       /* searchData: function() {
                var input = this. input;
                if ( input) {
                  
                    return this.tableData.filter(function(product) {
                        return Object.keys(product).some(function(key) {
                         
                            return String(product[key]).toLowerCase().indexOf(input) > -1

                        })
                    })
                }

                // console.log(this.tableData); 
            } */
    }
}
</script>

<style scoped>
/* 左侧数据区样式 */
.left{
  float: left;
  width: 65%;
  font-size: 18px;
  margin-left: 2%;
  border:1px solid rgba(204, 204, 204, 0.185);
}
.als span{
  display: inline-block;
  width: 140px;
  padding: 12px 0;
}
.als li{
  border-bottom: 1px solid rgba(204, 204, 204, 0.555);
}
.als .yul{
  width: 430px;
}

.el-breadcrumb{
  text-align: left;
  
}
.el-row{
  padding: 16px 30px;
  font-size: 16px;
  margin-bottom: 10px;
  border-bottom:.5px solid rgba(41, 0, 0, 0.158);
  color: rgba(90, 4, 4, 0.685);
}
.el-table{
  width: 100%;
  font-size: 16px;
  padding: 0px;
  color: rgba(8, 0, 0, 0.534);
}
/* 右边的盒子 */
.right{
  float: right;
  width: 340px;
  font-size: 16px;
  margin-top: -5px;
  margin-left: -5%;
  margin-right: 10px;
}
.right h4{
  height: 30px;
  line-height: 30px;
  color: rgba(61, 9, 9, 0.616);
  background: #ccc;
  padding-left:10px; 
}
.seek {
  display: flex;
}
.seek .el-input{
  float: left;
  flex-grow: 1;
  border: none;
  outline: 0 none;
    -webkit-appearance: none;
}
.seek .el-button{
  margin-left: 2px;
  }
.soone,.ranking{
  margin-top: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.ranking{
  height: 230px;
  overflow: hidden;
}
</style>
