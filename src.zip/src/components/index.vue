<template>
<div>
  <div class="header">
    <h5>个人博客</h5>
    
    <ul>
      <li class="el-dropdown-link" ><router-link   to="/sright"> 技术</router-link><i class="icon iconfont icon-unfold"></i></li>
      <li class="el-dropdown-link"><router-link  to="/sfenye"> 后台</router-link><i class="icon iconfont icon-unfold"></i></li>
    </ul>
    
  </div>
  <router-view></router-view>

  </div>


</template>

<script>

import selects from './selects'

export default {
  name: 'index',
  components: {
    selects
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.header{
  height: 60px;
  line-height: 60px;
  width: 100%;
  background: rgb(41, 0, 0);
  color: rgb(245, 230, 230);
}

.header h5{
  margin-left: 25px;
  float: left;
  font-size: 18px;
}
.header ul{
  float: left;
  margin-left: 10px;
  color: rgb(212, 196, 178);
}
.header ul a {
  color: rgb(212, 196, 178);
   text-decoration: none;
  
}
.header ul li{
  float: left;
  margin-left: 20px;
}
.header h5{
  font-size: 24px;
}
.header ul li i{
  font-size: 10px;
  margin-left: 5px;
}



</style>
