<template>
  <div>
    <div class="select">
      <el-row>
        <el-col :span="24"><div class="grid-content bg-purple-dark"><router-link   to="/"> 首页</router-link> <span>></span> 技术</div></el-col>
      </el-row>
  </div>  

  <router-view></router-view>
  </div>
</template>

<script>
export default {
  name:'sright',

}
</script>


<style scoped>
.el-row{
  padding: 16px 30px;
  font-size: 16px;
  margin-bottom: 10px;
  border-bottom:.5px solid rgba(41, 0, 0, 0.158);
  color: rgba(90, 4, 4, 0.685);
}
span{
  margin-left: 5px;
  margin-right: 5px;
}
</style>
