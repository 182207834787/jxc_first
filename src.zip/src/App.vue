<template>
  <div id="app">
  <index></index>


  </div>
</template>

<script>
import './assets/css/style.css'
import index from './components/index.vue'
export default {
  name: 'app',
  components: {
    index
  }
}
</script>

<style>

</style>
