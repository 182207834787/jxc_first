import Vue from 'vue'
import Router from 'vue-router'
import Selects from '@/components/selects'
import Sright from '@/components/sright'
import Sfenye from '@/components/sfenye'
// import Index from '@/components/index'

Vue.use(Router)

export default new Router({
  routes: [
    // {
    //   path: '/',
    //   name: 'index',
    //   component: Index
    // },
    {
      path: '/',
      name: 'selects',
      component: Selects
    },
    {
      path: '/sright',
      name: 'sright',
      component: Sright
    },
    {
      path: '/sfenye',
      name: 'sfenye',
      component: Sfenye
    }
  ]
})
